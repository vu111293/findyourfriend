package com.sgu.findyourfriend.mgr;

import android.location.Location;

public interface MyLocationChangeListener {
	public void onMyLocationChanged(Location location);
}
