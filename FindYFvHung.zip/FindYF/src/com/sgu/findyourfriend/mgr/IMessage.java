package com.sgu.findyourfriend.mgr;

import com.sgu.findyourfriend.model.Message;

public interface IMessage {

	public void addNewMessage(Message msg);
	
}
