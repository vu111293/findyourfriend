FIND YOUR FRIEND

Ứng dụng tham dự cuộc thi "Mùa hè sáng tạo 2014"
Mentor: Nguyễn Thùy Linh

Thành viên nhóm:
1. Trương Hữu Toàn.
2. Nguyễn Chí Hùng
3. Lê Quốc Vũ
